# Yaabaay App

Flutter Application

Google Play : https://play.google.com/store/apps/details?id=com.yaabaay.app

App Store : Soon

## Screen shots

![](imgs/1.png)