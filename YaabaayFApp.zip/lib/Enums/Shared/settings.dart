abstract class Settings {
  static const oneSignalAppId = 'fb712727-1a43-4bfb-a76a-5bc2c4eea7e0';
  static const facebookURL = 'https://www.facebook.com/yaabaayapp';
  static const twitterURL = 'https://twitter.com/yaabaayapp';
  static const instagramURL = 'https://www.instagram.com/yaabaayapp/';

}