abstract class StorageKeys {
  static const user = 'user';
  static const intro = 'intro';
  static const theme = 'theme';
  static const language = 'language';
}