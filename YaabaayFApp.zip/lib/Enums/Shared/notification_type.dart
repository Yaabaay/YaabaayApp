enum NotificationType {
  message,
}
