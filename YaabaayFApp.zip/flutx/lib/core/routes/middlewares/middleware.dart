abstract class FxMiddleware{

  Future<String> handle(String routeName);

}