package com.yaabaay.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
